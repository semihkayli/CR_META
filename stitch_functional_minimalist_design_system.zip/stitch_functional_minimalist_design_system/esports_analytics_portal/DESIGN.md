---
name: Esports Analytics Portal
colors:
  surface: '#1c1013'
  surface-dim: '#1c1013'
  surface-bright: '#443538'
  surface-container-lowest: '#160b0e'
  surface-container-low: '#25181b'
  surface-container: '#291c1f'
  surface-container-high: '#342629'
  surface-container-highest: '#3f3134'
  on-surface: '#f4dde0'
  on-surface-variant: '#debfc4'
  inverse-surface: '#f4dde0'
  inverse-on-surface: '#3b2d30'
  outline: '#a68a8f'
  outline-variant: '#574146'
  surface-tint: '#ffb1c3'
  primary: '#ffb1c3'
  on-primary: '#66002d'
  primary-container: '#9d174d'
  on-primary-container: '#ffafc2'
  inverse-primary: '#af275a'
  secondary: '#ffb867'
  on-secondary: '#482900'
  secondary-container: '#cb8011'
  on-secondary-container: '#3f2300'
  tertiary: '#87d990'
  on-tertiary: '#003913'
  tertiary-container: '#005f25'
  on-tertiary-container: '#85d78f'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffd9e0'
  primary-fixed-dim: '#ffb1c3'
  on-primary-fixed: '#3f0019'
  on-primary-fixed-variant: '#8e0542'
  secondary-fixed: '#ffddbb'
  secondary-fixed-dim: '#ffb867'
  on-secondary-fixed: '#2b1700'
  on-secondary-fixed-variant: '#673d00'
  tertiary-fixed: '#a2f6aa'
  tertiary-fixed-dim: '#87d990'
  on-tertiary-fixed: '#002108'
  on-tertiary-fixed-variant: '#00531f'
  background: '#1c1013'
  on-background: '#f4dde0'
  surface-variant: '#3f3134'
  night-navy: '#090d16'
  slate-white: '#f8fafc'
  royal-violet: '#6b21a8'
  slate-gray-dark: '#94a3b8'
  slate-gray-light: '#64748b'
  deep-slate: '#0f172a'
  legendary-blue-start: '#0284c7'
  legendary-blue-end: '#3b82f6'
typography:
  headline-lg:
    fontFamily: Outfit
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Outfit
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Outfit
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  margin-page: 2rem
  gutter: 1rem
  card-padding: 1.5rem
  unit: 4px
---

# Clash Royale Meta Deck Finder - Tasarım Kılavuzu (`DESIGN.md`)
Bu doküman, uygulamanın görsel standartlarını, koyu/açık mod renk paletini, tipografisini ve cam tasarımı (glassmorphism) kurallarını tanımlar. Tasarım, gözü yormayan asil e-spor analiz portalları estetiğine sahiptir.
---
## 1. Tasarım İlkeleri (Design Principles)
1.  **Maksimum Yalınlık & Netlik:** Sayfada dolgu yazılar, uzun pazarlama sloganları veya süsleyici gereksiz ögeler bulunamaz. Tasarım doğrudan veri odaklı ve temizdir.
2.  **E-Spor Estetiği (Premium Palette):** Çiğ parlak pembe/sarı neonlar yerine; kadife yakut kırmızısı, karamel kehribar altın ve derin gece mavisi zeminler kullanılır.
3.  **Çoklu Dil & Tema Esnekliği:** Başlıkta (Header) Açık/Koyu tema geçişi ile TR | EN dil seçimi için temiz ve sade kontroller yer alır.
---
## 2. Renk Değişkenleri (Color Tokens)
### 2.1 Koyu Tema Değişkenleri (Dark Theme - Default)
*   **Arka Plan (Night Navy):** `#090d16` (Çok koyu mat gece mavisi)
*   **Panel / Kart Zemini:** `rgba(15, 23, 42, 0.55)` (Yarı saydam koyu cam panel)
*   **Ana Metin:** `#f8fafc` (Slate beyaz)
*   **İkincil Metin:** `#94a3b8` (Mat gri)
*   **Cam Kenarlığı:** `rgba(255, 255, 255, 0.05)` (Çok ince saydam çizgi)
### 2.2 Açık Tema Değişkenleri (Light Theme)
*   **Arka Plan (Slate White):** `#f8fafc` (Slate beyazı temiz zemin)
*   **Panel / Kart Zemini:** `rgba(255, 255, 255, 0.7)` (Açık renk şeffaf cam panel)
*   **Ana Metin:** `#0f172a` (Koyu slate text)
*   **İkincil Metin:** `#64748b` (Orta mat gri)
*   **Cam Kenarlığı:** `rgba(15, 23, 42, 0.08)` (Çok ince saydam koyu çizgi)
### 2.3 Vurgu ve Nadirlik Renkleri (Accents)
*   **İksir Kırmızısı (Elixir Ruby - Primary):** `#9d174d` (Kadifemsi yakut/mürdüm kırmızısı)
*   **Şampiyon Kehribarı (Amber Gold):** `#c27803` (Mat antik altın rengi)
*   **Evrim Moru (Royal Violet):** `#6b21a8` (Kraliyet koyu moru)
*   **Legendary Gradyanı:** `linear-gradient(135deg, #0284c7 0%, #3b82f6 100%)` (Okyanus mavisi geçiş)
---
## 3. Tipografi (Typography)
*   **Başlıklar (h1, h2, h3):** `font-family: 'Outfit', sans-serif;` (Modern, net, kalın kesimler).
*   **Gövde Metinleri (body, input, buttons):** `font-family: 'Inter', sans-serif;` (Yüksek okunabilirlikli matris düzeni).
---
## 4. Efektler & Kart Tasarımları
*   **Cam Kart Yapısı (`.glass-card`):** `backdrop-filter: blur(12px); border-radius: 12px;`
*   **Eksik Kart Görünümü (Simülasyon):** Oyuncuda bulunmayan kartlar `%30` opaklığa düşürülerek tamamen siyah-beyaz (`filter: grayscale(100%)`) yapılır ve üzerinde kırmızı renkli küçük bir "KİLİTLİ" ibaresi taşır.
*   **Eksik Evrim Görünümü:** Mor kesikli çizgili ince çerçeveyle gösterilir ve üzerinde "EVO KİLİTLİ" yazar.
*   **Mikro Etkileşimler:** Butonlara tıklandığında hafifçe içeri basılma (`scale(0.96)`) ve kartların üzerine gelindiğinde yukarı kayma (`translateY(-4px)`) efekti uygulanır.